/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2019 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_debug_console.h"
#include "fsl_smc.h"
#include "fsl_pmc.h"
#include "pin_mux.h"
#include "peripherals.h"
#include "board.h"

#include "adc16_low_power_peripheral.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
/*
 * These values are used to get the temperature. DO NOT MODIFY
 * The method used in this demo to calculate temperature of chip is mapped to
 * Temperature Sensor for the HCS08 Microcontroller Family document (Document Number: AN3031)
 */

//#define DEMO_ADC16_CHANNEL_GROUP 0U

#define DEMO_ADC16_CHANNEL_TEMPSENSOR 0U


#define UPPER_VALUE_LIMIT                                                 \
    (1U) /*!< This value/10 is going to be added to current Temp to set \ \
              the upper boundary */
#define LOWER_VALUE_LIMIT                                                 \
    (1U) /*!< This Value/10 is going to be subtracted from current Temp \ \
              to set the lower boundary */


/*******************************************************************************
 * Variables
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/

/* Enable the trigger source of LPTimer */
void LPTMR_InitTriggerSourceOfAdc(LPTMR_Type *base)
{
    /* Start the LPTimer */
    LPTMR_StartTimer(base);

    /* Configure SIM for ADC hardware trigger source selection of Low-power timer (LPTMR) trigger. */
    BOARD_ConfigTriggerSource();
}

/*!
 * @brief ADC stop conversion
 */
void ADC16_PauseConversion(ADC_Type *base)
{
    adc16_channel_config_t adcChnConfig; /*!< ADC16 channel conversion configuration */

    /* Configure to set ADC channels measurement disabled */
    adcChnConfig.channelNumber                        = 31U;
    adcChnConfig.enableInterruptOnConversionCompleted = false;
#if defined(FSL_FEATURE_ADC16_HAS_DIFF_MODE) && FSL_FEATURE_ADC16_HAS_DIFF_MODE
    adcChnConfig.enableDifferentialConversion = false;
#endif

    /* Configure ADC channels */
    ADC16_SetChannelConfig(base, DEMO_ADC16_CHANNEL_GROUP, &adcChnConfig);
}

/*!
 * @brief Initialize the ADCx for Hardware trigger.
 */
bool ADC16_InitHardwareTrigger(ADC_Type *base)
{
#if defined(FSL_FEATURE_ADC16_HAS_CALIBRATION) && FSL_FEATURE_ADC16_HAS_CALIBRATION
    uint16_t offsetValue = 0; /*!< Offset error from correction value. */

    /* Auto calibration */
    if (kStatus_Success != ADC16_DoAutoCalibration(base))
    {
        return false;
    }
    offsetValue = base->OFS;
    ADC16_SetOffsetValue(base, offsetValue);
#endif

    /* enable hardware trigger  */
    ADC16_EnableHardwareTrigger(base, true);

    /* select kAdcChannelTemperature channel for measurement */
    ADC16_SetChannelConfig(base, DEMO_ADC16_CHANNEL_GROUP, &DEMO_ADC16_channelsConfig[DEMO_ADC16_CHANNEL_TEMPSENSOR]);

    return true;
}

lowPowerAdcBoundaries_t TempSensorCalibration(uint32_t updateBoundariesCounter, int32_t *tempArray)
{
    uint32_t avgTemp = 0;
    lowPowerAdcBoundaries_t boundaries;

    for (int i = 0; i < updateBoundariesCounter; i++)
    {
        avgTemp += tempArray[i];
    }
    /* Get average temperature */
    avgTemp /= updateBoundariesCounter;

    /* Set upper boundary */
    boundaries.upperBoundary = avgTemp + UPPER_VALUE_LIMIT;

    /* Set lower boundary */
    boundaries.lowerBoundary = avgTemp - LOWER_VALUE_LIMIT;

    return boundaries;
}

// EOF.
