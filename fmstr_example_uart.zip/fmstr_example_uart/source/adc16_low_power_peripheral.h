
/*
 * adc16_low_power_peripheral.h
 *
 *  Created on: Oct 12, 2023
 *      Author: judy_
 */

#ifndef ADC16_LOW_POWER_PERIPHERAL_H_
#define ADC16_LOW_POWER_PERIPHERAL_H_

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define LED2_TOGGLE() LED_GREEN_TOGGLE()
#define DEMO_ADC16_CHANNEL_GROUP 0U

/*!
 * @brief Boundaries structure
 */
typedef struct lowPowerAdcBoundaries
{
    int32_t upperBoundary; /*!< upper boundary in degree */
    int32_t lowerBoundary; /*!< lower boundary in degree */
} lowPowerAdcBoundaries_t;

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
/*!
 * @brief ADC stop conversion
 *
 * @param base The ADC instance number
 */
void ADC16_PauseConversion(ADC_Type *base);

/*!
 * @brief calibrate parameters: VDD and ADCR_TEMP25
 *
 * @param base The ADC instance number
 */
void ADC16_CalibrateParams(ADC_Type *base);

/*!
 * @brief Initialize the ADCx for HW trigger.
 *
 * @param base The ADC instance number
 *
 * @return true if success
 */
bool ADC16_InitHardwareTrigger(ADC_Type *base);

/*!
 * @brief User-defined function to init trigger source  of LPTimer
 *
 * @param base The LPTMR instance number
 */
void LPTMR_InitTriggerSourceOfAdc(LPTMR_Type *base);

/*!
 * @brief Calculate current temperature.
 *
 * @return uint32_t Returns current temperature.
 */
int32_t GetCurrentTempValue(void);

/*!
 * @brief Calculate current temperature.
 *
 * @param updateBoundariesCounter Indicate number of values into tempArray.
 *
 * @param tempArray Store temperature value.
 *
 * @return lowPowerAdcBoundaries_t Returns upper and lower temperature boundaries.
 */
lowPowerAdcBoundaries_t TempSensorCalibration(uint32_t updateBoundariesCounter, int32_t *tempArray);

/*******************************************************************************
 * Variables
 ******************************************************************************/

#endif /* ADC16_LOW_POWER_PERIPHERAL_H_ */
