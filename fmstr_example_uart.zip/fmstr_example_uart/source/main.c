/*
 * Copyright (c) 2007-2015 Freescale Semiconductor, Inc.
 * Copyright 2018-2019 NXP
 *
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * FreeMASTER Communication Driver - Example Application
 */

////////////////////////////////////////////////////////////////////////////////
// Includes
////////////////////////////////////////////////////////////////////////////////

#include "pin_mux.h"
#include "fsl_uart.h"
#include "fsl_common.h"
#include "board.h"

#include "freemaster.h"
#include "freemaster_serial_uart.h"

#include "freemaster_example.h"

// for ADC
#include "fsl_smc.h"
#include "fsl_pmc.h"
#include "peripherals.h"
#include "adc16_low_power_peripheral.h"

#if ENABLE_ADC
/*******************************************************************************
 * Definitions
 ******************************************************************************/
/*
 * These values are used to get the temperature. DO NOT MODIFY
 * The method used in this demo to calculate temperature of chip is mapped to
 * Temperature Sensor for the HCS08 Microcontroller Family document (Document Number: AN3031)
 */
#define ADCR_VDD      (65535U) /* Maximum value when use 16b resolution */
#define V_BG          (1000U)  /* BANDGAP voltage in mV (trim to 1.0V) */
#define V_TEMP25      (716U)   /* Typical VTEMP25 in mV */
#define M             (1620U)  /* Typical slope: (mV x 1000)/oC */

#define LED1_ON()  LED_RED_ON()
#define LED1_OFF() LED_RED_OFF()

#define LED2_ON()     LED_GREEN_ON()
#define LED2_OFF()    LED_GREEN_OFF()
//#define LED2_TOGGLE() LED_GREEN_TOGGLE()

#define LED3_ON()  LED_BLUE_ON()
#define LED3_OFF() LED_BLUE_OFF()

#define UPDATE_BOUNDARIES_TIME                                              \
    (20U) /*!< This value indicates the number of cycles needed to update \ \
               boundaries. To know the Time it will take, \                 \
               multiply this value by period set in DEMO_LPTMR_INPUT_FREQ \ \
               for LPTMR interrupt time in period of 500 milliseconds */
#define STANDARD_TEMP (25U)

#define DEMO_ADC16_CHANNEL_BANDGAP    1U

#endif

////////////////////////////////////////////////////////////////////////////////
// Variables
////////////////////////////////////////////////////////////////////////////////

//! Note: All global variables accessed by FreeMASTER are defined in a shared
//! freemaster_example.c file

////////////////////////////////////////////////////////////////////////////////
// Prototypes
////////////////////////////////////////////////////////////////////////////////


static void init_freemaster_uart(void);

/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile static uint32_t g_adcValue = 0; /*!< ADC value */
static uint32_t g_adcrTemp25        = 0; /*!< Calibrated ADCR_TEMP25 */
static uint32_t g_adcr100m          = 0;
volatile bool g_conversionCompleted = false; /*!< Conversion is completed flag */


////////////////////////////////////////////////////////////////////////////////
// Code
////////////////////////////////////////////////////////////////////////////////
#if ENABLE_ADC
/*!
 * @brief calibrate parameters: VDD and ADCR_TEMP25
 */
void ADC16_CalibrateParams(ADC_Type *base)
{
    uint32_t bandgapValue = 0; /*!< ADC value of BANDGAP */
    uint32_t vdd          = 0; /*!< VDD in mV */

    pmc_bandgap_buffer_config_t pmcBandgapConfig;

    pmcBandgapConfig.enable = true;

#if (defined(FSL_FEATURE_PMC_HAS_BGEN) && FSL_FEATURE_PMC_HAS_BGEN)
    pmcBandgapConfig.enableInLowPowerMode = false;
#endif
#if (defined(FSL_FEATURE_PMC_HAS_BGBDS) && FSL_FEATURE_PMC_HAS_BGBDS)
    pmcBandgapConfig.drive = kPmcBandgapBufferDriveLow;
#endif
    /* Enable BANDGAP reference voltage */
    PMC_ConfigureBandgapBuffer(PMC, &pmcBandgapConfig);

    /*
     * Initialization of ADC for 16-bit resolution, interrupt mode, HW trigger disabled,
     * normal conversion speed, VREFH/L as reference and disabled continuous convert mode.
     */
    BOARD_InitADCPeripheral(); /*!< Initialization of the ADC16 peripheral */

#if defined(FSL_FEATURE_ADC16_HAS_CALIBRATION) && FSL_FEATURE_ADC16_HAS_CALIBRATION
    /* Auto calibration */
    if (kStatus_Success == ADC16_DoAutoCalibration(base))
    {
        //PRINTF("ADC16_DoAutoCalibration() Done.\r\n");
    }
    else
    {
        //PRINTF("ADC16_DoAutoCalibration() Failed.\r\n");
    }
#endif

    /* select kAdcChannelBandgap channel for measurement */
    ADC16_SetChannelConfig(base, DEMO_ADC16_CHANNEL_GROUP, &DEMO_ADC16_channelsConfig[DEMO_ADC16_CHANNEL_BANDGAP]);

    /* Wait for the conversion to be done */
    while (!ADC16_GetChannelStatusFlags(base, DEMO_ADC16_CHANNEL_GROUP))
    {
    }

    /* Get current ADC BANDGAP value */
    bandgapValue = ADC16_GetChannelConversionValue(base, DEMO_ADC16_CHANNEL_GROUP);

    ADC16_PauseConversion(base);

    /* Get VDD value measured in mV: VDD = (ADCR_VDD x V_BG) / ADCR_BG */
    vdd = ADCR_VDD * V_BG / bandgapValue;
    /* Calibrate ADCR_TEMP25: ADCR_TEMP25 = ADCR_VDD x V_TEMP25 / VDD */
    g_adcrTemp25 = ADCR_VDD * V_TEMP25 / vdd;
    /* ADCR_100M = ADCR_VDD x M x 100 / VDD */
    g_adcr100m = (ADCR_VDD * M) / (vdd * 10);

    /* Disable BANDGAP reference voltage */
    pmcBandgapConfig.enable = false;
    PMC_ConfigureBandgapBuffer(PMC, &pmcBandgapConfig);
}

int32_t GetCurrentTempValue(void)
{
    int32_t currentT = 0;
    /* Temperature = 25 - (ADCR_T - ADCR_TEMP25) * 100 / ADCR_100M */
    currentT =
        (int32_t)(STANDARD_TEMP - ((int32_t)g_adcValue - (int32_t)g_adcrTemp25) * 100 / (int32_t)g_adcr100m);
    return currentT;
}


/*!
 * @brief ADC Interrupt handler
 *
 * Get current ADC value and set g_conversionCompleted flag.
 */

void DEMO_ADC16_IRQHANDLER(void)
{
    /* GREEN LED is blinking indicating the initial temperature measurement is still in progress */
    LED2_TOGGLE();

    /* Get current ADC value */
    g_adcValue = ADC16_GetChannelConversionValue(DEMO_ADC16_PERIPHERAL, DEMO_ADC16_CHANNEL_GROUP);
    /* Set conversion completed flag. This prevents an wrong conversion in main function */
    g_conversionCompleted = true;
    SDK_ISR_EXIT_BARRIER;
}
#endif


int main(void)
{
#if ENABLE_ADC
	int32_t currentTemperature       = 0;
	uint32_t updateBoundariesCounter = 0;
	int32_t tempArray[UPDATE_BOUNDARIES_TIME * 2];
	lowPowerAdcBoundaries_t boundaries;
	int32_t temperatureValue       = 0;
#endif

    /* Board initialization */
    BOARD_InitPins();
    BOARD_BootClockRUN();
#if ENABLE_ADC
    BOARD_InitPeripherals();

    /* Set to allow entering vlps mode */
    SMC_SetPowerModeProtection(SMC, kSMC_AllowPowerModeVlp);

    /* Calibrate param Temperature sensor */
    ADC16_CalibrateParams(DEMO_ADC16_PERIPHERAL);

    /* Initialize Demo ADC */
    if (!ADC16_InitHardwareTrigger(DEMO_ADC16_PERIPHERAL))
    {
    	return -1;
    }

    /* setup the HW trigger source for ADC */
    LPTMR_InitTriggerSourceOfAdc(LPTMR0);
#endif

    /* FreeMASTER communication layer initialization */
    init_freemaster_uart();

    /* This example uses shared code from FreeMASTER generic example application */
    FMSTR_Example_Init();

#if ENABLE_ADC
    /* Warm up microcontroller and allow to set first boundaries */
    while (updateBoundariesCounter < (UPDATE_BOUNDARIES_TIME * 2))
    {

        while (!g_conversionCompleted)
        {
         	/* FreeMASTER example increments several variables periodically,
           	   use the FreeMASTER PC Host tool to visualize the variables */
        	FMSTR_Example_Poll(currentTemperature, temperatureValue);
        }

        currentTemperature = GetCurrentTempValue();
        temperatureValue = g_adcValue;

        tempArray[updateBoundariesCounter] = currentTemperature;
        updateBoundariesCounter++;
        g_conversionCompleted = false;
    }


    /* Temp Sensor Calibration */
    boundaries              = TempSensorCalibration(updateBoundariesCounter, tempArray);
    updateBoundariesCounter = 0;

    LPTMR_StopTimer(LPTMR0);

    /* GREEN LED is turned on indicating that initial measurement is finished */
    LED_GREEN_ON();

    LPTMR_StartTimer(LPTMR0);

    while (1)
    {
            /* Prevents the use of wrong values */
            while (!g_conversionCompleted)
            {
               	/* FreeMASTER example increments several variables periodically,
            	       use the FreeMASTER PC Host tool to visualize the variables */
            	FMSTR_Example_Poll(currentTemperature, temperatureValue);
            }

            /* Get current Temperature Value */
            currentTemperature = GetCurrentTempValue();
            temperatureValue = g_adcValue;
            /* Store temperature values that are going to be use to calculate average temperature */
            tempArray[updateBoundariesCounter] = currentTemperature;

            if (currentTemperature > boundaries.upperBoundary)
            {
                LED1_ON(); /*! RED LED is turned on when temperature is above the average */
                LED2_OFF();
                LED3_OFF();
            }
            else if (currentTemperature < boundaries.lowerBoundary)
            {
                LED1_OFF();
                LED2_OFF();
                LED3_ON(); /*! BLUE LED is turned on when temperature is below the average */
            }
            else
            {
                LED1_OFF();
                LED2_ON(); /*! GREEN LED is turned on when temperature is around the average */
                LED3_OFF();
            }

            /* Call update function */
            if (updateBoundariesCounter >= (UPDATE_BOUNDARIES_TIME))
            {
                boundaries              = TempSensorCalibration(updateBoundariesCounter, tempArray);
                updateBoundariesCounter = 0;
            }
            else
            {
                updateBoundariesCounter++;
            }

            /* Clear conversion completed flag */
            g_conversionCompleted = false;

    }
#endif

}



/*!
 * @brief UART Module initialization (UART is a the standard block included e.g. in K22F)
 */
static void init_freemaster_uart(void)
{
    uart_config_t config;

    /*
     * config.baudRate_Bps = 115200U;
     * config.parityMode = kUART_ParityDisabled;
     * config.stopBitCount = kUART_OneStopBit;
     * config.txFifoWatermark = 0;
     * config.rxFifoWatermark = 1;
     * config.enableTx = false;
     * config.enableRx = false;
     */
    UART_GetDefaultConfig(&config);
    config.baudRate_Bps = 115200U;
    config.enableTx = false;
    config.enableRx = false;

    UART_Init((UART_Type*)BOARD_DEBUG_UART_BASEADDR, &config, BOARD_DEBUG_UART_CLK_FREQ);

    /* Register communication module used by FreeMASTER driver. */
    FMSTR_SerialSetBaseAddress((UART_Type*)BOARD_DEBUG_UART_BASEADDR);

#if FMSTR_SHORT_INTR || FMSTR_LONG_INTR
    /* Enable UART interrupts. */
    EnableIRQ(BOARD_UART_IRQ);
    EnableGlobalIRQ(0);
#endif
}

#if FMSTR_SHORT_INTR || FMSTR_LONG_INTR
/*
*   Application interrupt handler of communication peripheral used in interrupt modes
*   of FreeMASTER communication.
*
*   NXP MCUXpresso SDK framework defines interrupt vector table as a part of "startup_XXXXXX.x"
*   assembler/C file. The table points to weakly defined symbols, which may be overwritten by the
*   application specific implementation. FreeMASTER overrides the original weak definition and
*   redirects the call to its own handler.
*
*/

void BOARD_UART_IRQ_HANDLER(void)
{
    /* Call FreeMASTER Interrupt routine handler */
    FMSTR_SerialIsr();
    /* Add for ARM errata 838869, affects Cortex-M4, Cortex-M4F Store immediate overlapping
        exception return operation might vector to incorrect interrupt */
#if defined __CORTEX_M && (__CORTEX_M == 4U)
    __DSB();
#endif
}
#endif

////////////////////////////////////////////////////////////////////////////////
// EOF
/////////////////////////////////////////////////////////////////////////////////
